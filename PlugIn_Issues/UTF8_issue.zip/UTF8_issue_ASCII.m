xASCII={A\:f3daA};
yASCII=coeff\:0df4A\:02d6A\:2794Y\:02d6A;

