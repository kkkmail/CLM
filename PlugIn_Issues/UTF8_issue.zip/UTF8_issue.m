x={AA};
y=coeff෴A˖A➔Y˖A;

